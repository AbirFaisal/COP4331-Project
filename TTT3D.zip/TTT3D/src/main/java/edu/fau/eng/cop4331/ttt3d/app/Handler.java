package edu.fau.eng.cop4331.ttt3d.app;

import java.awt.event.ActionEvent;

public interface Handler {
    void handle(ActionEvent value);
}
