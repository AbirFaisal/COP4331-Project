package edu.fau.eng.cop4331.ttt3d.app.game;

/**
 * The type of game to launch
 */
public enum GameType {
    SINGLE_PLAYER_GAME,
    MULTI_PLAYER_CLIENT_GAME,
    MULTI_PLAYER_HOST_GAME
}
