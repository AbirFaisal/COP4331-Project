package edu.fau.eng.cop4331.ttt3d.server;

//TODO make abstract
public interface Service {
    Object getResponse();
}
