package edu.fau.eng.cop4331.ttt3d.server.services;

public class ChatService {
    /**
     * Handle the message sent from a client
     * @param message Object that will be deserialized into a String
     */
    void processMessage(Object message){};
}
