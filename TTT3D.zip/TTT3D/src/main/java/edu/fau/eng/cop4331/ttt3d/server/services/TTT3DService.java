package edu.fau.eng.cop4331.ttt3d.server.services;

public class TTT3DService {

    /**
     * Handle the move sent from a client
     * @param move Object that will be deserialized into a gameState: int[][][]
     */
    void handleGame(Object move){
    }
}
