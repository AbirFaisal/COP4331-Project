import edu.fau.eng.cop4331.ttt3d.server.Server;
import org.junit.jupiter.api.Test;

import java.io.IOException;

public class ServerTest {




    @Test
    public void testServer() throws IOException {
        Server server = new Server();
//        server.run();

    }

}
